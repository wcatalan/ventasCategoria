
package Test;

import java.util.Scanner;

public class TestVentas {
      
    public static void main(String[] args) {
        Infor();
        int op = 0;
        do{
            System.out.println("\t*** MENU ***\n");
            System.out.println("1- Insertar nuevo registro");
            System.out.println("2- Mostrar la Base de Datos");
            System.out.println("3- Modificar un registro");
            System.out.println("4- Eliminar un registro");
            System.out.println("5- Salir");
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    ActionCRUD.InsertData();
                     break;
                case 2:
                    System.out.println(">>> Extrayendo la base de datos, por favor espere!...");
                    ActionCRUD.ExtraerData();
                     break;
                case 3:
                    ActionCRUD.UpdateData();
                     break;
                case 4:
                     ActionCRUD.DeleteData();
                     break;
            }
        }while(op != 5);
        System.out.println(">>> PROGRAMA TERMINADO <<<");
    }
    
    public static void Infor(){
       System.out.println("\nPROGRAMACÓN APLICADA 1");
       System.out.println("\nINTEGRANTES:"); 
       System.out.println("Marlon Enrique Moran Guevara");
       System.out.println("Jairo Vladimir Osorio Portillo");
       System.out.println("Wilmer Omar Alvarez Sanchez");
       System.out.println("Welner Edgardo Catalan Rivera");
       System.out.println("Kevin Miguel Henriquez Perez\n");
    }
}
