package datos;

import domain.Marca;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MarcaJDBC {

    private static final String SQL_SELECT = "SELECT * FROM marca";
    private static final String SQL_INSERT = "INSERT INTO marca (marca) VALUES (?)";
    private static final String SQL_UPDATE = "UPDATE marca SET marca = ? WHERE idMarca = ?";
    private static final String SQL_DELETE = "DELETE FROM marca WHERE idMarca =?";

    public List<Marca> select() {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        Marca marca = null;
        List<Marca> marcas = new ArrayList<Marca>();

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();

            while (rs.next()) {
                marca = new Marca();
                marca.setIdMarca(rs.getInt("idMarca"));
                marca.setMarca(rs.getString("marca"));
                marcas.add(marca); //almacenando cada objeto en la lista
            }

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return marcas;
    }

    public int insert(Marca marca) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            // INSERT INTO marca (marca) VALUES (?)
            stmt.setString(1, marca.getMarca());
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados: " + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }

    public int update(Marca marca) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            // UPDATE marca SET marca = ? WHERE idMarca = ?
            stmt.setString(1, marca.getMarca());
            stmt.setInt(2, marca.getIdMarca());
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados: " + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }

    public int delete(Marca marca) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            // DELETE FROM marca WHERE idMarca =?
            stmt.setInt(1, marca.getIdMarca());
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados: " + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return rows;
    }
}
