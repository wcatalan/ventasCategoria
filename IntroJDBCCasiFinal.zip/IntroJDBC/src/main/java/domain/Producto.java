
package domain;
public class Producto {
    private int idProducto;
    private int idCategoria; 
    private int idPresentacion;
    private int idMarca;
    private String descripcion; 
    private double precio;
    private double costo;
    private int stock;

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public int getIdPresentacion() {
        return idPresentacion;
    }

    public void setIdPresentacion(int idPresentacion) {
        this.idPresentacion = idPresentacion;
    }

    public int getIdMarca() {
        return idMarca;
    }

    public void setIdMarca(int idMarca) {
        this.idMarca = idMarca;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override 
    public String toString(){
        
         return"Producto {\n\nidProducto: " + idProducto +"\nidCategoria: "+idCategoria + ",  \nidPresentacion: "+ idPresentacion + ",  \nidmarca: "+ idMarca +
                 ",  \ndescripcion: " + descripcion + "\nprecio: "+precio + "\ncosto: "+costo+"\nstock: "+stock+"}";
    }
}
