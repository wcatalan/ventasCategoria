
package domain;

public class Categoria {
    
    private int idCategoria;
    private String categoria;

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getcategoria() {
        return categoria;
    }

    public void setcategoria(String categoria) {
        this.categoria = categoria;
    }
    
    @Override
    public String toString(){
        return "idCategoria: " + idCategoria + "| Categoria: " + categoria;
    }
    
}
