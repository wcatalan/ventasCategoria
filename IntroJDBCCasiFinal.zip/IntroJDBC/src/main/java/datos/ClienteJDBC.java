package datos;
import domain.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteJDBC {
    //CRUD
    private static final String SQL_SELECT ="SELECT * FROM cliente";
    private static final String SQL_INSERT = "INSERT INTO cliente (nombre,direccion,email,telefono) values (?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE cliente set nombre=?, direccion=?, email=?, telefono=? WHERE idCliente = ?";
    private static final String SQL_DELETE = "DELETE FROM cliente WHERE idCliente =?";
    
    public List<Cliente> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;        
        Cliente persona = null;
        List<Cliente> personas = new ArrayList<Cliente>();        
        try{
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs= stmt.executeQuery();
            while(rs.next()){
                String direccion = rs.getString("direccion");
                String mail = rs.getString("email");
                String telefono = rs.getString("telefono");                
                persona = new Cliente();
                persona.setIdCliente(rs.getInt("idCliente"));
                persona.setNombre(rs.getString("nombre"));                
                persona.setDireccion(direccion);
                persona.setEmail(mail);
                persona.setTelefono(telefono);                
                personas.add(persona);   //almacenando cada objeto en la lista            
            }            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);            
        }finally{
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
    
        return personas;
    }
    public static int insert(Cliente gente){
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, gente.getNombre());
            stmt.setString(2, gente.getDireccion());
            stmt.setString(3, gente.getEmail());
            stmt.setString(4, gente.getTelefono());            
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados:" + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            Conexion.close(stmt);
            Conexion.close(conn);
        }        
        return rows;
    }
    

    public static int update(Cliente persona){
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = Conexion.getConnection();
            System.out.println("ejecutando query: " + SQL_UPDATE);
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, persona.getNombre());
            stmt.setString(2, persona.getDireccion());
            stmt.setString(3, persona.getEmail());
            stmt.setString(4, persona.getTelefono());
            stmt.setInt(5, persona.getIdCliente());
            
            rows = stmt.executeUpdate();
            System.out.println("Registros actualizado:" + rows);
            
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return rows;
    }
    

    public static int delete(Cliente persona){
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        
        try {
            conn = Conexion.getConnection();
            System.out.println("Ejecutando query:" + SQL_DELETE);
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, persona.getIdCliente());
            rows = stmt.executeUpdate();
            System.out.println("Registros eliminados:" + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return rows;
    }
}
