
package datos;
import domain.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    private static  final String SQL_SELECT="SELECT * FROM producto";
    private static  final String SQL_INSERT="INSERT INTO producto(idCategoria,idPresentacion,idMarca,descripcion,precio,costo,stock) values (?,?,?,?,?,?,?)";
    private static  final String SQL_UPDATE ="UPDATE producto SET idCategoria=?,idPresentacion=?,idMarca=?,descripcion=?,precio=?,costo=?,stock=? WHERE idProducto = ?";
    private static final String SQL_DELETE =" DELETE FROM producto WHERE idProducto =?";

    public List<Producto>select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs= null;
        
        Producto producto = null;
        List<Producto> products=new ArrayList<Producto>();
        
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_SELECT);
            rs=stmt.executeQuery();
            
            while(rs.next() ){
                producto= new Producto();
                producto.setIdProducto(rs.getInt("idProducto"));
                producto.setIdCategoria(rs.getInt("idCategoria"));
                producto.setIdPresentacion(rs.getInt("idPresentacion"));
                producto.setIdMarca(rs.getInt("idMarca"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setPrecio(rs.getDouble("precio"));
                producto.setCosto(rs.getDouble("costo"));
                producto.setStock(rs.getInt("stock"));
   
                products.add(producto);
                
            }
            
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
            Conexion.close(rs);
        }
        
        return products;
    }
    
    public static int insert(Producto product){
        int row = 0;
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_INSERT);
            stmt.setInt(1, product.getIdCategoria());
            stmt.setInt(2, product.getIdPresentacion());
            stmt.setInt(3, product.getIdMarca());
            stmt.setString(4, product.getDescripcion());
            stmt.setDouble(5, product.getPrecio());
            stmt.setDouble(6, product.getCosto());
            stmt.setInt(7, product.getStock());
            
            row =stmt.executeUpdate();
            System.out.println("Registro insertado correctamente");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
            System.out.println("Datos no insertados!");
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return row;
    }
    
    public static int update(Producto product){
         Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, product.getIdCategoria());
            stmt.setInt(2, product.getIdPresentacion());
            stmt.setInt(3, product.getIdMarca());
            stmt.setString(4, product.getDescripcion());
            stmt.setDouble(5, product.getPrecio());
            stmt.setDouble(6, product.getCosto());
            stmt.setInt(7,product.getStock());
            stmt.setInt(8, product.getIdProducto());
            result=stmt.executeUpdate();
            System.out.println("Fila Afectada: "+result);
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
    
    public static int delete(Producto person){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
            System.out.println("Query: "+SQL_DELETE);
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, person.getIdProducto());
            result=stmt.executeUpdate();
            System.out.println("Rgistro Eliminado: "+result);
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
}
